package com.exam.vo;

public class RBoardVO {
		
		private int num;
		private String username;
		private String restaurant;
		private String area;
		private String cuisine;
		private int rating;
		private int price;
		
		public int getNum() {
			return num;
		}
		public void setNum(int num) {
			this.num = num;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getRestaurant() {
			return restaurant;
		}
		public void setRestaurant(String restaurant) {
			this.restaurant = restaurant;
		}
		public String getArea() {
			return area;
		}
		public void setArea(String area) {
			this.area = area;
		}
		public String getCuisine() {
			return cuisine;
		}
		public void setCuisine(String cuisine) {
			this.cuisine = cuisine;
		}
		public int getRating() {
			return rating;
		}
		public void setRating(int rating) {
			this.rating = rating;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "RBoardVO [num=" + num + ", username=" + username + ", restaurant=" + restaurant + ", area=" + area
					+ ", cuisine=" + cuisine + ", rating=" + rating + ", price=" + price + "]";
		}
		

}

package com.exam.vo;

public class AttachVO {
	private String uuid;
	private String uploadpath;
	private String filename;
	private String filetype; // "I"는 Image파일타입(jpg,gif,png)
	private int rbno;
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getUploadpath() {
		return uploadpath;
	}
	public void setUploadpath(String uploadpath) {
		this.uploadpath = uploadpath;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public int getRbno() {
		return rbno;
	}
	public void setRbno(int rbno) {
		this.rbno = rbno;
	}
	@Override
	public String toString() {
		return "AttachVO [uuid=" + uuid + ", uploadpath=" + uploadpath + ", filename=" + filename + ", filetype="
				+ filetype + ", rbno=" + rbno + "]";
	}

	
	
}	
package com.exam.vo;

import java.sql.Timestamp;

public class DBoardVO {

	
	private int num;
	private String username;
	private String subject;
	private String content;
	private int readcount;
	private String ip;
	private Timestamp regDate;
	private int reRef;
	private int reLev;	
	private int reSeq;
	private String uploadpath;
	private String filename;
	private String filetype;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getReadcount() {
		return readcount;
	}
	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Timestamp getRegDate() {
		return regDate;
	}
	public void setRegDate(Timestamp regDate) {
		this.regDate = regDate;
	}
	public int getReRef() {
		return reRef;
	}
	public void setReRef(int reRef) {
		this.reRef = reRef;
	}
	public int getReLev() {
		return reLev;
	}
	public void setReLev(int reLev) {
		this.reLev = reLev;
	}
	public int getReSeq() {
		return reSeq;
	}
	public void setReSeq(int reSeq) {
		this.reSeq = reSeq;
	}
	public String getUploadpath() {
		return uploadpath;
	}
	public void setUploadpath(String uploadpath) {
		this.uploadpath = uploadpath;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	@Override
	public String toString() {
		return "DBoardVO [num=" + num + ", username=" + username + ", subject=" + subject + ", content=" + content
				+ ", readcount=" + readcount + ", ip=" + ip + ", regDate=" + regDate + ", reRef=" + reRef + ", reLev="
				+ reLev + ", reSeq=" + reSeq + ", uploadpath=" + uploadpath + ", filename=" + filename + ", filetype="
				+ filetype + "]";
	}
	
	
}
	
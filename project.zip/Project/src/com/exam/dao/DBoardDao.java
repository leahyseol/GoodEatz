package com.exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.exam.vo.AttachVO;
import com.exam.vo.BoardVO;
import com.exam.vo.DBoardVO;

public class DBoardDao {
	
	private static DBoardDao instance = new DBoardDao();

	public static DBoardDao getInstance() {
		return instance;
	}

	private DBoardDao() {}
	
	
	// 첨부파일정보 입력하기 메소드
	public void insertAttach(DBoardVO DBoardVO) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBManager.getConnection();
			String sql = ("INSERT INTO jspdb.dboard (num, username, passwd, subject, content, readcount, ip, reg_date, re_ref, re_lev, re_seq) ");
			sql += "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, DBoardVO.getNum());
			pstmt.setString(2, DBoardVO.getUsername());
			pstmt.setString(3, DBoardVO.getSubject());
			pstmt.setString(4, DBoardVO.getContent());
			
			
			pstmt.setInt(5, DBoardVO.getReadcount());
			pstmt.setString(6, DBoardVO.getIp());
			pstmt.setTimestamp(7, DBoardVO.getRegDate());
			pstmt.setInt(8, DBoardVO.getReRef());
			pstmt.setInt(9, DBoardVO.getReLev());
			pstmt.setInt(10, DBoardVO.getReSeq());

			pstmt.setString(11, DBoardVO.getUploadpath());
			pstmt.setString(12, DBoardVO.getFilename());
			pstmt.setString(13, DBoardVO.getFiletype());
			
		
			
			// 실행
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt);
		}
	} // insertAttach method
	
	
	// 글번호에 해당하는 첨부파일정보 가져오기
	public List<DBoardVO> getAttaches(int bno) {
		List<DBoardVO> list = new ArrayList<DBoardVO>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBManager.getConnection();
			
			String sql = "SELECT * FROM jspdb.DBoard WHERE bno = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			// 실행
			rs = pstmt.executeQuery();
			while (rs.next()) {
				DBoardVO DBoardVO = new DBoardVO();
				
				DBoardVO.setNum(rs.getInt("num"));
				DBoardVO.setUsername(rs.getString("username"));
				DBoardVO.setSubject(rs.getString("subject"));
				DBoardVO.setContent(rs.getString("content"));
				DBoardVO.setReadcount(rs.getInt("readcount"));
				DBoardVO.setIp(rs.getString("ip"));
				DBoardVO.setRegDate(rs.getTimestamp("reg_date"));
				DBoardVO.setReRef(rs.getInt("re_ref"));
				DBoardVO.setReLev(rs.getInt("re_lev"));
				DBoardVO.setReSeq(rs.getInt("re_seq"));
				
				DBoardVO.setFilename(rs.getString("filename"));
				DBoardVO.setFiletype(rs.getString("filetype"));
		
				
				list.add(DBoardVO);
			} // while
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}
		return list;
	} // getAttach method
	
	
	// 게시판 글번호에 해당하는 첨부파일정보 삭제하는 메소드
	public void deleteAttach(int bno) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBManager.getConnection();
			String sql = "DELETE FROM jspdb.DBoard WHERE bno = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			// 실행
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt);
		}
	} // deleteAttach method
	
	public void deleteAttach(String uuid) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con=DBManager.getConnection();
			String sql="DELETE FROM jspdb.DBoard WHERE uuid = ?";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, uuid);
			
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBManager.close(con, pstmt);
		}
	}
	// 특정 레코드의 조회수를 1 증가시키는 메소드
		public void updateReadcount(int num) {
			Connection con = null;
			PreparedStatement pstmt = null;
			StringBuilder sb = new StringBuilder();
			
			try {
				con = DBManager.getConnection();
				sb.append("UPDATE jspdb.DBoard ");
				sb.append("SET readcount = readcount + 1 ");
				sb.append("WHERE num = ?");
				
				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, num);
				// 실행
				pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt);
			}
		} // updateReadcount method
		// 글 한개를 가져오는 메소드
		public DBoardVO getBoard(int num) {
			DBoardVO DBoardVO = null;
			
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try {
				con = DBManager.getConnection();
				String sql = "SELECT * FROM jspdb.DBoard WHERE num = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				// 실행
				rs = pstmt.executeQuery();
				if (rs.next()) {
					DBoardVO = new DBoardVO();
					DBoardVO.setNum(rs.getInt("num"));
					DBoardVO.setUsername(rs.getString("username"));
					DBoardVO.setSubject(rs.getString("subject"));
					DBoardVO.setContent(rs.getString("content"));
					DBoardVO.setReadcount(rs.getInt("readcount"));
					DBoardVO.setIp(rs.getString("ip"));
					DBoardVO.setRegDate(rs.getTimestamp("reg_date"));
					DBoardVO.setReRef(rs.getInt("re_ref"));
					DBoardVO.setReLev(rs.getInt("re_lev"));
					DBoardVO.setReSeq(rs.getInt("re_seq"));
					DBoardVO.setUploadpath(rs.getString("uploadpath"));
					DBoardVO.setFilename(rs.getString("filename"));
					DBoardVO.setFiletype(rs.getString("filetype"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt, rs);
			}
			return DBoardVO;
		} // getBoard method
		
		public int getBoardCount(String search) {
			int count = 0;
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			try {
				con = DBManager.getConnection();
				String sql = "SELECT COUNT(*) FROM jspdb.dboard ";
				
				// 동적(Dynamic) SQL
				if (!(search == null || search.equals(""))) {
					sql += "WHERE subject LIKE ? ";
				}
				
				pstmt = con.prepareStatement(sql);
				
				
				if (!(search == null || search.equals(""))) {
					pstmt.setString(1, "%"+search+"%");
				}
				
				// 실행
				rs = pstmt.executeQuery();
				
				rs.next(); // 커서 옮겨서 행 존재유무 true/false 리턴
				
				count = rs.getInt(1); // 행개수 count변수에 저장
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt, rs);
			}
			return count;
		} // getBoardCount method
		
		public List<DBoardVO> getBoards(int startRow, int pageSize, String search) {
			List<DBoardVO> list = new ArrayList<DBoardVO>();
			//int endRow = startRow + pageSize - 1; // 오라클전용 끝행번호
			
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			StringBuilder sb = new StringBuilder();
			
			sb.append("SELECT * ");
			sb.append("FROM jspdb.dboard ");
			
			// 검색어 search가 있을때는 검색조건절 where를 추가함
			if (!(search == null || search.equals(""))) {
				sb.append("WHERE subject LIKE ? ");
			}
			
			sb.append("ORDER BY re_ref DESC, re_seq ASC ");
			sb.append("LIMIT ? OFFSET ? ");
			
			try {
				con = DBManager.getConnection();
				pstmt = con.prepareStatement(sb.toString());
				
				if (!(search == null || search.equals(""))) {
					// 검색어가 있을때
					pstmt.setString(1, "%" + search + "%");
					pstmt.setInt(2, pageSize);
					pstmt.setInt(3, startRow - 1);
				} else {
					// 검색어가 없을때
					pstmt.setInt(1, pageSize);
					pstmt.setInt(2, startRow - 1);
				}
				
				// 실행
				rs = pstmt.executeQuery();
				while (rs.next()) {
					DBoardVO dboardVO = new DBoardVO();
					dboardVO.setNum(rs.getInt("num"));
					dboardVO.setUsername(rs.getString("username"));
					dboardVO.setSubject(rs.getString("subject"));
					dboardVO.setContent(rs.getString("content"));
					dboardVO.setReadcount(rs.getInt("readcount"));
					dboardVO.setIp(rs.getString("ip"));
					dboardVO.setRegDate(rs.getTimestamp("reg_date"));
					dboardVO.setReRef(rs.getInt("re_ref"));
					dboardVO.setReLev(rs.getInt("re_lev"));
					dboardVO.setReSeq(rs.getInt("re_seq"));
					dboardVO.setUploadpath(rs.getString("Uploadpath"));
					dboardVO.setFilename(rs.getString("filename"));
					dboardVO.setFiletype(rs.getString("filetype"));
					
					
					// 리스트에 vo객체 한개 추가
					list.add(dboardVO);
				} // while
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt, rs);
			}
			return list;
		} // getBoards method
		
		public void insertBoard(DBoardVO DBoardVO) {
			Connection con = null;
			PreparedStatement pstmt = null;
			StringBuilder sb = new StringBuilder();
			
			try {
				con = DBManager.getConnection();
				
				sb.append("INSERT INTO jspdb.dboard (num, username, subject, content, readcount, ip, reg_date, re_ref, re_lev, re_seq, uploadpath, filename, filetype) ");
				sb.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, DBoardVO.getNum());
				pstmt.setString(2, DBoardVO.getUsername());
				pstmt.setString(3, DBoardVO.getSubject());
				pstmt.setString(4, DBoardVO.getContent());
				pstmt.setInt(5, DBoardVO.getReadcount());
				pstmt.setString(6, DBoardVO.getIp());
				pstmt.setTimestamp(7, DBoardVO.getRegDate());
				pstmt.setInt(8, DBoardVO.getReRef());
				pstmt.setInt(9, DBoardVO.getReLev());
				pstmt.setInt(10, DBoardVO.getReSeq());
				pstmt.setString(11, DBoardVO.getUploadpath());
				pstmt.setString(12, DBoardVO.getFilename());
				pstmt.setString(13, DBoardVO.getFiletype());
			
				
				// 실행
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt);
			}
		} // insertBoard method
		
		public boolean isPasswdEqual(int num, String passwd) {
			System.out.println("num : " + num + ", passwd : " + passwd);
			
			boolean result = false;
			
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT COUNT(*) ");
			sb.append("FROM jspdb.dboard ");
			sb.append("WHERE num = ? ");
			sb.append("AND passwd = ? ");
			
			try {
				con = DBManager.getConnection();
				pstmt = con.prepareStatement(sb.toString());
				pstmt.setInt(1, num);
				pstmt.setString(2, passwd);
				// 실행
				rs = pstmt.executeQuery();
				
				rs.next(); // 커서 내리기
				
				int count = rs.getInt(1); // 카운트값 가져오기
				if (count == 1) {
					result = true; // 게시글 패스워드 같음
				} else { // count == 0
					result = false; // 게시글 패스워드 다름
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt, rs);
			}
			return result;
		} // isPasswdEqual method
		
		// 글번호에 해당하는 글 한개 삭제하기 메소드
		public void deleteBoard(int num) {
			Connection con = null;
			PreparedStatement pstmt = null;
			
			try {
				con = DBManager.getConnection();
				String sql = "DELETE FROM jspdb.dboard WHERE num = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				// 실행
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt);
			}
		} // deleteBoard method
		
		public int nextBoardNum() {
			int num = 0;
			Connection con = null;
			Statement stmt = null;
			ResultSet rs = null;
			
			try {
				con = DBManager.getConnection();
				// num 컬럼값중에 최대값 구하기. 레코드 없으면 null
				String sql = "SELECT MAX(num) FROM jspdb.dboard";
				stmt = con.createStatement();
				rs = stmt.executeQuery(sql);
				// rs 레코드값 있으면 num = 최대값 + 1
				//             없으면 num = 1
				if (rs.next()) {
					num = rs.getInt(1) + 1;
				} else {
					num = 1;
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, stmt, rs);
			}
			return num;
		} // nextBoardNum method
		
		
		
		// 게시글 수정하기 메소드
		public void updateBoard(DBoardVO dboardVO) {
			Connection con = null;
			PreparedStatement pstmt = null;
			
			String sql = "";
			sql  = "UPDATE dboard ";
			sql += "SET subject = ?, content = ?, filename = ? ";
			sql += "WHERE num = ? ";
			
			try {
				con = DBManager.getConnection();
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, dboardVO.getSubject());
				pstmt.setString(2, dboardVO.getContent());
				pstmt.setInt(3, dboardVO.getNum());
				// 실행
				pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(con, pstmt);
			}
		} // updateBoard method
	
	
}

package com.exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.exam.vo.AttachVO;
import com.exam.vo.BoardVO;
import com.exam.vo.RBoardVO;

public class RBoardDao {

	private static RBoardDao instance = new RBoardDao();

	public static RBoardDao getInstance() {
		return instance;
	}

	private RBoardDao() {
	}

	public int nextrboardNum() {
		int num = 0;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			con = DBManager.getConnection();
			String sql = "SELECT MAX(num) FROM jspdb.rboard";
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, stmt, rs);
		}
		return num;

	}

	// 게시글 한개 등록하는 메소드
	public void insertrboard(RBoardVO rboardVO) {
		Connection con = null;
		PreparedStatement pstmt = null;
		StringBuilder sb = new StringBuilder();

		try {
			con = DBManager.getConnection();

			sb.append("INSERT INTO rboard(num, username, restaurant, area, cuisine, rating, price) ");
			sb.append("VALUES(?, ?, ?, ?, ?, ?, ?) ");
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, rboardVO.getNum());
			pstmt.setString(2, rboardVO.getUsername());
			pstmt.setString(3, rboardVO.getRestaurant());
			pstmt.setString(4, rboardVO.getArea());
			pstmt.setString(5, rboardVO.getCuisine());
			pstmt.setInt(6, rboardVO.getRating());
			pstmt.setInt(7, rboardVO.getPrice());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt);
		}
	}
	
	public RBoardVO getRBoard(int num) {
		RBoardVO rboardVO = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBManager.getConnection();
			String sql = "SELECT * FROM jspdb.rboard WHERE num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				rboardVO = new RBoardVO();
				rboardVO.setNum(rs.getInt("num"));
				rboardVO.setUsername(rs.getString("username"));
				rboardVO.setRestaurant(rs.getString("restaurant"));
				rboardVO.setArea(rs.getString("area"));
				rboardVO.setCuisine(rs.getString("cuisine"));
				rboardVO.setRating(rs.getInt("rating"));
				rboardVO.setPrice(rs.getInt("price"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}
		return rboardVO;
	}

	// 첨부파일정보 입력하기 메소드
	public void insertAttach(RBoardVO rboardVO) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBManager.getConnection();
			String sql = "INSERT INTO jspdb.rboard (num, username, restaurant, area, cuisine, rating, price) ";
			sql += "VALUES (?, ?, ?, ?, ?, ?, ?)";

			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, rboardVO.getNum());
			pstmt.setString(2, rboardVO.getUsername());
			pstmt.setString(3, rboardVO.getRestaurant());
			pstmt.setString(4, rboardVO.getArea());
			pstmt.setString(5, rboardVO.getCuisine());
			pstmt.setInt(6, rboardVO.getRating());
			pstmt.setInt(7, rboardVO.getPrice());

			// 실행
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt);
		}
	} // insertAttach method

	// 글번호에 해당하는 첨부파일정보 가져오기
	public List<RBoardVO> getAttaches(int rbno) {
		List<RBoardVO> list = new ArrayList<RBoardVO>();

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBManager.getConnection();

			String sql = "SELECT * FROM jspdb.rboard WHERE rbno = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, rbno);
			// 실행
			rs = pstmt.executeQuery();
			while (rs.next()) {

				RBoardVO rboardVO = new RBoardVO();

				rboardVO.setNum(rs.getInt("num"));
				rboardVO.setUsername(rs.getString("username"));
				rboardVO.setRestaurant(rs.getString("restaurant"));
				rboardVO.setArea(rs.getString("area"));
				rboardVO.setCuisine(rs.getString("cuisine"));
				rboardVO.setRating(rs.getInt("rating"));
				rboardVO.setPrice(rs.getInt("price"));

				list.add(rboardVO);
			} // while
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}
		return list;
	} // getAttach method

	// 글번호에 해당하는 글 한개 삭제하기 메소드
	public void deleteRBoard(int num) {
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBManager.getConnection();
			String sql = "DELETE FROM jspdb.rboard WHERE num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			// 실행
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt);
		}
	} // deleteBoard method

	public int getRBoardCount(String search) {
		int count = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBManager.getConnection();
			String sql = "SELECT COUNT(*) FROM jspdb.rboard";

			if (!(search == null || search.equals(""))) {
				sql +="WHERE num LIKE ?";
			}
			pstmt= con.prepareStatement(sql);
			
			if(!(search== null || search.equals(""))) {
				pstmt.setString(1, "%" + search + "%");
			}
			rs = pstmt.executeQuery();
			rs.next();
			count = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}

		return count;

	}
	
	
	public List<RBoardVO> getRBoards(int startRow, int pageSize, String search) {
		List<RBoardVO> list = new ArrayList<RBoardVO>();
		//int endRow = startRow + pageSize - 1; // 오라클전용 끝행번호
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sb = new StringBuilder();
		
		sb.append("SELECT * ");
		sb.append("FROM rboard ");
		
		// 검색어 search가 있을때는 검색조건절 where를 추가함
		if (!(search == null || search.equals(""))) {
			sb.append("WHERE restaurant LIKE ? ");
		}
		
		sb.append("ORDER BY num DESC ");
		sb.append("LIMIT ? OFFSET ? ");
		
		try {
			con = DBManager.getConnection();
			pstmt = con.prepareStatement(sb.toString());
			
			if (!(search == null || search.equals(""))) {
				// 검색어가 있을때
				pstmt.setString(1, "%" + search + "%");
				pstmt.setInt(2, pageSize);
				pstmt.setInt(3, startRow - 1);
			} else {
				// 검색어가 없을때
				pstmt.setInt(1, pageSize);
				pstmt.setInt(2, startRow - 1);
			}
			
			// 실행
			rs = pstmt.executeQuery();
			while (rs.next()) {
				RBoardVO rboardVO = new RBoardVO();
				rboardVO.setNum(rs.getInt("num"));
				rboardVO.setUsername(rs.getString("username"));
				rboardVO.setRestaurant(rs.getString("restaurant"));
				rboardVO.setArea(rs.getString("area"));
				rboardVO.setCuisine(rs.getString("cuisine"));
				rboardVO.setRating(rs.getInt("rating"));
				rboardVO.setPrice(rs.getInt("price"));
				// 리스트에 vo객체 한개 추가
				list.add(rboardVO);
			} // while
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}
		return list;
	} // getBoards method
	

	public void updateRBoard(RBoardVO rboardVO) {
		Connection con = null;
		PreparedStatement pstmt = null;

		String sql = "";
		sql = "UPDATE jspdb.rboard";
		sql += "SET subject = ?, content = ?";
		sql += "WHERE num= ?";
		
		try {
			con = DBManager.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, rboardVO.getNum());
			pstmt.setString(2, rboardVO.getRestaurant());
			pstmt.setString(3, rboardVO.getArea());
			pstmt.executeUpdate();
	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt);
		}

	}
	
	public boolean isPasswdEqual(int num, String passwd) {
		System.out.println("num: " + num + ", passwd: " + passwd);
		
		boolean result=false;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT COUNT(*)" );
		sb.append("FROM jspdb.rboard");
		sb.append("WHERE num = ?");
		sb.append("AND passwd = ?");
		
		try {
			con = DBManager.getConnection();
			pstmt= con.prepareStatement(sb.toString());
			pstmt.setInt(1, num);
			pstmt.setString(2, passwd);
			
			rs=pstmt.executeQuery();
			rs.next();
			
			int count = rs.getInt(1);
			if(count == 1) {
				result=true;
			} else {
				result = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}
		return result;
		
	}
		
//	public void reInsertRBoard(RBoardVO rboardVO) {
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		String sql = "";
//	
//	try {
//		con=DBManager.getConnection();
//		con.setAutoCommit(false);
//		
//		
//		sql ="UPDATE jspdb.rboard";
//		sql += ""
//	} catch (Exception e) {
//		// TODO: handle exception
//		e.printStackTrace();
//	} finally {
//		DBManager.close(con, pstmt);
//	}
//
//}
//	
//	
//	
//	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}